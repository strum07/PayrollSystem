        <div class="header">
            <h2>Edit Employee Data</h2>
        </div>

        <div class="content">
            <h2 class="content-subhead">Enter Search Criteria</h2>
            
				<form method=POST action="index.php?page=editList" class="pure-form">
					<input type=text name=search width=10>
					<button>Find Matching Employees</button>
				</form>
              
			<?php include 'php/footer.php'; ?>

       </div>